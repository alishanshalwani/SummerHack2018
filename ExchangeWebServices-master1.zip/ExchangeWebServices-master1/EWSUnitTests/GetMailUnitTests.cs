﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ExchangeWebServices;
using System.Data;

namespace EWSUnitTests
{
    [TestClass]
    public class GetMailUnitTests
    {
        EWS exchange;

        [TestInitialize]
        public void TestInit()
        {
            exchange = new EWS();

            exchange.Authenticate("324129543", "Jabra!#Phone!", "MAPLE", "tyler.babin@rbc.com", "", out string definedService);
        }

        [TestMethod]
        public void Test_GetMail_ReturnsOneEmail_WhenFolderHasOneUnreadEmail()
        {

            exchange.GetMailBp(true, true, "tyler.babin@rbc.com", out DataTable EmailCollection, out DataTable Unprocessed, out decimal numEmails,
                out decimal totalAttachments, out string error);

            Assert.AreEqual(1, EmailCollection.Rows.Count);
        }

        /// <summary>
        /// 
        /// </summary>
        [TestMethod]
        public void Test_GetMail_ReturnsNoEmails_WhenNoUnreadInFolder()
        {
            exchange.GetMailBp(true, true, "tyler.babin@rbc.com", out DataTable EmailCollection, out DataTable Unprocessed, out decimal numEmails,
                out decimal totalAttachments, out string error);

            Assert.AreEqual(0, EmailCollection.Rows.Count);
        }

        /// <summary>
        /// Assumptions - At least one unread email with attachments is in the PPOC folder. All of these attachments are able to be saved to a file
        /// on disk.
        /// </summary>
        [TestMethod]
        public void Test_GetMail_ReturnsNoEmailsInUnprocessedCollection_WhenAbleToSaveAllAttachments()
        {
            exchange.GetMailBp(true, true, "tyler.babin@rbc.com", out DataTable EmailCollection, out DataTable Unprocessed, out decimal numEmails,
                out decimal totalAttachments, out string error, subFolder: "PPOC", AttachmentDir:"C:\\temp\\ews");

            Assert.AreEqual(0, Unprocessed.Rows.Count);
        }

        /// <summary>
        /// Assumptions - One unread email in the PPOC folder has attachments that are unable to be saved to a file.
        /// </summary>
        [TestMethod]
        public void Test_GetMail_ReturnsOneEmailInUnprocessedCollection_WhenUnableToSaveAllAttachments()
        {
            exchange.GetMailBp(true, false, "tyler.babin@rbc.com", out DataTable EmailCollection, out DataTable Unprocessed, out decimal numEmails,
                out decimal totalAttachments, out string error, subFolder: "PPOC", AttachmentDir: "C:\\temp\\ews");

            Assert.AreEqual(1, Unprocessed.Rows.Count);
        }

        /// <summary>
        /// Assumptions - Two emails are marked as unread in the PPOC folder. One of those emails has attachments that are unable to
        /// be saved to a file.
        /// </summary>
        [TestMethod]
        public void Test_GetMail_ReturnsOneEmailInCollection_WhenUnableToSaveAllAttachments_TwoEmails()
        {
            exchange.GetMailBp(true, false, "tyler.babin@rbc.com", out DataTable EmailCollection, out DataTable Unprocessed, out decimal numEmails,
                out decimal totalAttachments, out string error, subFolder: "PPOC", AttachmentDir: "C:\\temp\\ews");

            Assert.AreEqual(1, EmailCollection.Rows.Count);
        }

        /// <summary>
        /// Assumptions - Get Mail recently moved one email to the Unprocessed Emails folder because it was unable to
        /// save the attachments of that email to a file
        /// </summary>
        [TestMethod]
        public void Test_GetMail_ReturnsOneEmailInCollection_WhenRetrievingFromUnprocessedFolder()
        {
            exchange.GetMailBp(true, false, "tyler.babin@rbc.com", out DataTable EmailCollection, out DataTable Unprocessed, out decimal numEmails,
                out decimal totalAttachments, out string error, subFolder: "Unprocessed Emails");

            Assert.AreEqual(1, EmailCollection.Rows.Count);
        }
    }
}
