﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace BluePrismLoggingFramework
{
    public static class Logger
    {
        public static string FileName { get; set; }

        public static List<Stopwatch> Timers { get; set; } = new List<Stopwatch>();

        public static LogLevel Level { get; set; }

        public static void Log(LogLevel level, string message)
        {
            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Blue Prism Limited", FileName ?? "log.txt");

            if (Level == LogLevel.OFF || !Level.Equals(level) && Level != LogLevel.DEBUG)
                return;

            using (StreamWriter streamWriter = File.AppendText(path))
                streamWriter.WriteLine("{0} {1}\t {2}", DateTime.Now.ToLongTimeString(), DateTime.Now.ToShortDateString(), message);
        }

        public static void LogNoDate(string message)
        {
            using (StreamWriter streamWriter = File.AppendText(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Blue Prism Limited", FileName ?? "log.txt")))
                streamWriter.WriteLine("{0}", message);
        }

        public static void StartTimer()
        {
            Stopwatch stopwatch = new Stopwatch();
            Timers.Add(stopwatch);
            stopwatch.Start();
        }

        public static void StopTimer()
        {
            if (Timers.Count <= 0)
                return;

            Stopwatch timer = Timers[Timers.Count - 1];
            Timers.Remove(timer);

            if (timer.IsRunning)
                timer.Stop();

            TimeSpan elapsed = timer.Elapsed;

            string str = string.Format("{0:00}:{1:00}:{2:00}.{3:00}", elapsed.Hours, elapsed.Minutes, elapsed.Seconds, (elapsed.Milliseconds / 10));
            if (Level == LogLevel.DEBUG)
                LogNoDate("Elapsed Time: " + str);
        }

        public static void LoadConfig()
        {
            string logLevel = string.Empty;

            try
            {
                logLevel = XElement.Load(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Blue Prism Limited", "config.xml"))
                                    .Elements()
                                    .Where(x => x.Name == "LogLevel")
                                    .FirstOrDefault().Value;
            }
            catch
            {
                logLevel = "OFF";
            }

            switch (logLevel.ToLower())
            {
                case "debug":
                    Level = LogLevel.DEBUG;
                    break;
                case "production":
                    Level = LogLevel.PRODUCTION;
                    break;
                default:
                    Level = LogLevel.OFF;
                    break;
            }
        }
    }

    public enum LogLevel
    {
        DEBUG,
        OFF,
        PRODUCTION
    }
}
