﻿using System.Net;
using BluePrismLoggingFramework;
using Microsoft.Exchange.WebServices.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.DirectoryServices;


namespace ExchangeWebServices
{
    public class EWS
    {


        public struct LDAP
        {
            //whatever the namespace, we were registered as 8R02 in LDAP...
            public const string HostAddress = "globdir.fg.rbc.com";
            public const string UserId = "ou=8R02,ou=applications,dc=fg,dc=rbc,dc=com";
            public const string UserPassword = "02BPRSce";
            public const string Object = "/ou=people,dc=fg,dc=rbc,dc=com";
        }

        public struct LDAP_SAI
        {
            //whatever the namespace, we were registered as 8R02 in LDAP...
            //public const string HostAddress = "globgdir.saifg.rbc.com";
            //Host has chanaged, email on 2010 Jan 11 @ 3:53 PM, Subject: GDS in SAi
            public const string HostAddress = "globsai.saifg.rbc.com";
            public const string UserId = "ou=8R02,ou=applications,dc=fg,dc=rbc,dc=com";
            public const string UserPassword = "BPRS8r02";
            public const string Object = "/ou=people,dc=fg,dc=rbc,dc=com";
        }

        public struct LDAP_DEV
        {
            //whatever the namespace, we were registered as 8R02 in LDAP...
            //public const string HostAddress = "globdir.fg.rbc.com";
            public const string HostAddress = "globdev.saifg.rbc.com";
            public const string UserId = "ou=8R02,ou=applications,dc=fg,dc=rbc,dc=com";
            //public const string UserPassword = "02BPRSce";
            public const string UserPassword = "BPRS8r02";
            public const string Object = "/ou=people,dc=fg,dc=rbc,dc=com";
        }





        public ExchangeService Service { get; set; }

        public void Authenticate(string username, string password, string domain, string emailAddress, string serviceUrl, out string definedServiceUrl)
        {
            Logger.Log(LogLevel.PRODUCTION, string.Format("Authenticating into email address({0})", emailAddress));
            Logger.StartTimer();

            if (Service == null)
            {
                Service = new ExchangeService(ExchangeVersion.Exchange2010_SP2);

                if (serviceUrl == "")
                {
                    try
                    {
                        Logger.Log(LogLevel.DEBUG, string.Format("attempting to auto discover the web service for {0}", emailAddress));
                        Service.AutodiscoverUrl(emailAddress);
                    }
                    catch (Exception ex)
                    {
                        Logger.Log(LogLevel.PRODUCTION, string.Format("caught exception when trying to auto discover service.\t{0}", ex.Message));
                        Logger.StopTimer();
                        Logger.LogNoDate("\r\n");
                    }
                }
                else
                {
                    Logger.Log(LogLevel.DEBUG, string.Format("serviceUrl = {0}; not autodiscovering...", serviceUrl));
                    Service.Url = new Uri(serviceUrl);
                }

                Logger.Log(LogLevel.DEBUG, string.Format("service assigned... Attempting to set the web credentials with username {0}", username));
                Service.Credentials = new WebCredentials(username, password, domain);

                Logger.Log(LogLevel.PRODUCTION, "authentication and service discovery is done.");
                Logger.StopTimer();
                Logger.LogNoDate("\r\n");
            }

            definedServiceUrl = Service.Url.ToString();
        }

        private Folder GetChildSubfolder(string folderStructure, string mailboxName, out string errorMessage)
        {
            Logger.Log(LogLevel.PRODUCTION, string.Format("attempting to get child subfolder ID of the following structure: {0}", folderStructure));
            Logger.StartTimer();
            Folder folderRoot;
            FolderId folderRootId = null;
            Folder subFolder = null;
            errorMessage = string.Empty;
            try
            {
                Logger.Log(LogLevel.DEBUG, string.Format("attempting to bind to the MsgFolderRoot of the mailbox {0}", mailboxName));
                folderRootId = new FolderId(WellKnownFolderName.MsgFolderRoot, new Mailbox(mailboxName));
                folderRoot = Folder.Bind(Service, folderRootId);
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                Logger.Log(LogLevel.PRODUCTION, string.Format("failed to bind to the MsgFolderRoot of the mailbox {0}", mailboxName));
                Logger.StopTimer();
                Logger.LogNoDate("\r---");
                return null;
            }

            if (!folderStructure.Contains("/"))
            {
                subFolder = Service.FindFolders(folderRootId, new FolderView(50)).Where(x => x.DisplayName == folderStructure).FirstOrDefault();
                Logger.Log(LogLevel.DEBUG, string.Format("found subFolder {0}", subFolder.DisplayName));
                Logger.StopTimer();
                Logger.LogNoDate("\r---");
                return subFolder;
            }
            else
            {
                string[] folderNames = folderStructure.Split('/');

                for (int i = 1; i < folderNames.Length; i++)
                {
                    Logger.Log(LogLevel.DEBUG, string.Format("searching through the provided folder structure; currently processing: {0}", folderNames[i - 1]));
                    Folder parent = folderRoot.FindFolders(new FolderView(50)).Where(x => x.DisplayName == folderNames[i - 1]).FirstOrDefault();
                    if (parent == null)
                    {
                        errorMessage = "Could not find parent folder: " + folderNames[i - 1];
                        Logger.Log(LogLevel.PRODUCTION, errorMessage);
                        Logger.StopTimer();
                        Logger.LogNoDate("\r---");
                        return null;
                    }
                    subFolder = parent.FindFolders(new FolderView(50)).Where(y => y.DisplayName == folderNames[i]).FirstOrDefault();
                    folderRoot = parent;
                }
                if (subFolder != null)
                    Logger.Log(LogLevel.DEBUG, string.Format("done retrieving child subfolder {0}", subFolder.DisplayName));
                else
                    Logger.Log(LogLevel.DEBUG, string.Format("done retrieving child subfolder {0}", "null"));
                Logger.StopTimer();
                Logger.LogNoDate("\r---");
                return subFolder;
            }
        }

        private Folder CreateFolder(string folderName, string emailAddress, out string errorMessage)
        {
            Logger.Log(LogLevel.PRODUCTION, string.Format("attempting to create folder structure: {0}", folderName));
            Logger.StartTimer();
            Folder f = null;
            errorMessage = "";

            try
            {
                Logger.Log(LogLevel.DEBUG, "creating new blank folder on service URL");
                f = new Folder(Service);
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                Logger.Log(LogLevel.PRODUCTION, string.Format("failed to create blank folder on service URL\t{0}", errorMessage));
                Logger.StopTimer();
                Logger.LogNoDate("\r---");
                return null;
            }

            // ex: "New Folder", will be created on the same tier as Inbox
            if (!folderName.Contains("/"))
            {
                f.DisplayName = folderName;
                try
                {
                    Logger.Log(LogLevel.DEBUG, string.Format("attempting to save new folder {0} in the MsgFolderRoot of {1}", folderName, emailAddress));
                    f.Save(new FolderId(WellKnownFolderName.MsgFolderRoot, new Mailbox(emailAddress)));
                }
                // thrown if folder already exists
                catch (ServiceResponseException)
                {
                    Logger.Log(LogLevel.DEBUG, string.Format("folder {0} already exists in the MsgFolderRoot", folderName));
                    Logger.StopTimer();
                    Logger.LogNoDate("\r---");
                    var parent = new FolderId(WellKnownFolderName.MsgFolderRoot, new Mailbox(emailAddress));
                    return Folder.Bind(Service, parent).FindFolders(new FolderView(50)).Where(x => x.DisplayName == folderName).FirstOrDefault();
                }
            }
            else
            {
                string[] folders = folderName.Split('/');
                // ex: "x/y/.../z"
                if (folders.Length > 1)
                {
                    Folder folderRoot = Folder.Bind(Service, new FolderId(WellKnownFolderName.MsgFolderRoot, new Mailbox(emailAddress)));

                    // loop through the folder hierarchy to get the direct parent of the child subfolder. Will create hierarchy if does not exist        
                    for (int i = 0; i < folders.Length - 1; i++)
                    {
                        Logger.Log(LogLevel.DEBUG, string.Format("attempting to find root folder {0}", folders[i]));
                        Folder parent = folderRoot.FindFolders(new FolderView(50)).Where(x => x.DisplayName == folders[i]).FirstOrDefault();
                        if (parent == null)
                        {
                            Logger.Log(LogLevel.DEBUG, string.Format("{0} was not found. Creating hierarchy {1}...", folders[i], string.Join("/", folders, 0, i + 1)));
                            // recurse through this method to create the parent folder
                            parent = CreateFolder(string.Join("/", folders, 0, i + 1), emailAddress, out errorMessage);
                        }
                        folderRoot = parent;
                    }
                    f.DisplayName = folders[folders.Length - 1];
                    f.Save(folderRoot.Id);
                }
            }
            Logger.Log(LogLevel.PRODUCTION, string.Format("new folder {0} has been created", f.DisplayName));
            Logger.StopTimer();
            Logger.LogNoDate("\r---");

            return f;
        }
        private void GetAttachments(EmailMessage msg, int currentEmailCount, string attachmentDir)
        {
            foreach (Attachment attachment in msg.Attachments)
            {
                if (attachment is FileAttachment)
                {
                    FileAttachment file = attachment as FileAttachment;
                    var fileName = currentEmailCount + "_" + CleanSpecialCharacters(file.Name);
                    var path = Path.Combine(attachmentDir, fileName);

                    try
                    {
                        file.Load(path);
                    }
                    catch (Exception ex)
                    {
                        var fileList = Directory.GetFiles(attachmentDir, currentEmailCount.ToString() + @"*");
                        foreach (var fileToDelete in fileList)
                        {
                            File.Delete(fileToDelete);
                        }
                        throw new FailedToSaveAttachmentException(string.Format("failed to save file to {0}\t{1}", path, ex.Message), ex);
                    }
                }
                else
                {
                    ItemAttachment itemAttachment = attachment as ItemAttachment;
                    itemAttachment.Load(EmailMessageSchema.MimeContent);
                    var itemName = currentEmailCount + "_" + CleanSpecialCharacters(itemAttachment.Name);
                    var path = Path.Combine(attachmentDir, itemName) + ".eml";
                    try
                    {
                        File.WriteAllBytes(path, itemAttachment.Item.MimeContent.Content);
                    }
                    catch (Exception ex)
                    {
                        var fileList = Directory.GetFiles(attachmentDir, currentEmailCount.ToString() + @"*");
                        foreach (var fileToDelete in fileList)
                        {
                            File.Delete(fileToDelete);
                        }
                        throw new FailedToSaveAttachmentException(string.Format("failed to save file to {0}\t{1}", path, ex.Message), ex);
                    }
                }
            }
        }

        private string CleanSpecialCharacters(string old)
        {
            return old.Replace("\\", "")
                      .Replace("/", "")
                      .Replace("\"", "")
                      .Replace("*", "")
                      .Replace(":", "")
                      .Replace(";", "")
                      .Replace("?", "")
                      .Replace("<", "")
                      .Replace(">", "")
                      .Replace("|", "");
        }

        public void GetMailBp(bool UnreadOnly, bool GetOldest, string ServiceEmailAddress, out DataTable EmailCollection,
                                   out DataTable UnprocessedEmailCollection, out decimal NumberOfEmails, out decimal TotalAttachmentCount,
                                   out string sErrorMessage, bool IncludeEmailAddresses = false, string subFolder = "",
                                   string moveToSubFolder = "", string AttachmentDir = "", bool Delete = false)
        {
            Logger.Log(LogLevel.PRODUCTION, string.Format("attempting to retrieve emails from {0}", ServiceEmailAddress));
            Logger.StartTimer();

            // initialize variables
            sErrorMessage = string.Empty;
            StringBuilder builder = new StringBuilder();
            EmailCollection = new DataTable();
            UnprocessedEmailCollection = new DataTable();
            FolderId folderToSearch = null;
            FolderId destinationFolderId = null;
            string toList = string.Empty;
            string ccList = string.Empty;
            string attachmentNames = string.Empty;
            NumberOfEmails = 0;
            TotalAttachmentCount = 0;

            // build the datatable that will be sent as the out parameter
            EmailCollection.Columns.Add("Sender_Name");
            EmailCollection.Columns.Add("Sender_Email_Address");
            EmailCollection.Columns.Add("Subject");
            EmailCollection.Columns.Add("Body");
            EmailCollection.Columns.Add("Received_Time");
            EmailCollection.Columns.Add("Sent_Time");
            EmailCollection.Columns.Add("To");
            EmailCollection.Columns.Add("CC");
            EmailCollection.Columns.Add("Attachment_Count");
            EmailCollection.Columns.Add("Attachment_Names");
            EmailCollection.Columns.Add("ID");

            UnprocessedEmailCollection.Columns.Add("Sender_Name");
            UnprocessedEmailCollection.Columns.Add("Sender_Email_Address");
            UnprocessedEmailCollection.Columns.Add("Subject");
            UnprocessedEmailCollection.Columns.Add("Body");
            UnprocessedEmailCollection.Columns.Add("Received_Time");
            UnprocessedEmailCollection.Columns.Add("Sent_Time");
            UnprocessedEmailCollection.Columns.Add("To");
            UnprocessedEmailCollection.Columns.Add("CC");
            UnprocessedEmailCollection.Columns.Add("Attachment_Count");
            UnprocessedEmailCollection.Columns.Add("Attachment_Names");
            UnprocessedEmailCollection.Columns.Add("ID");

            // set up the filters, view, and folder
            FindItemsResults<Item> findResults = null;
            SearchFilter sf;
            if (UnreadOnly)
                sf = new SearchFilter.SearchFilterCollection(LogicalOperator.And,
                                                        new SearchFilter.IsNotEqualTo(EmailMessageSchema.IsRead, UnreadOnly));
            else
                sf = new SearchFilter.SearchFilterCollection(LogicalOperator.Or,
                                new SearchFilter.IsEqualTo(EmailMessageSchema.IsRead, UnreadOnly),
                                new SearchFilter.IsEqualTo(EmailMessageSchema.IsRead, !UnreadOnly));
            // will batch retrieve 1000 emails at a time
            ItemView view = new ItemView(1000, 0);
            view.Traversal = ItemTraversal.Shallow;

            // orders by oldest or newest
            view.OrderBy.Add(ItemSchema.DateTimeReceived, GetOldest ? Microsoft.Exchange.WebServices.Data.SortDirection.Ascending
                : Microsoft.Exchange.WebServices.Data.SortDirection.Descending);
            PropertySet propSet = new PropertySet(BasePropertySet.FirstClassProperties) { RequestedBodyType = BodyType.Text };
            view.PropertySet = propSet;

            // Looks for a subfolder to search in
            // This will look at the very root of the folder tree
            if (subFolder != "")
            {
                Logger.Log(LogLevel.DEBUG, string.Format("attempting to retrieve a folder ID for the folder {0}", subFolder));
                Folder sub = GetChildSubfolder(subFolder, ServiceEmailAddress, out sErrorMessage);
                if (sub != null)
                    folderToSearch = sub.Id.UniqueId;
                else
                {
                    sErrorMessage = "Failed to open " + subFolder;
                    Logger.Log(LogLevel.PRODUCTION, string.Format("failed to retrieve ID of subfolder {0}\t{1}", subFolder, sErrorMessage));
                    Logger.StopTimer();
                    Logger.LogNoDate("\r---");
                    return;
                }
            }
            else
                folderToSearch = new FolderId(WellKnownFolderName.Inbox, new Mailbox(ServiceEmailAddress));

            // Looks for the folder ID of the subfolder the emails will be moved to
            // This will look at the very root of the folder tree
            if (moveToSubFolder != "")
            {
                Logger.Log(LogLevel.DEBUG, string.Format("attempting to retrieve a folder ID for the folder {0}", moveToSubFolder));
                Folder emailDestination = GetChildSubfolder(moveToSubFolder, ServiceEmailAddress, out sErrorMessage);
                if (emailDestination != null)
                    destinationFolderId = emailDestination.Id.UniqueId;
                else
                {
                    Logger.Log(LogLevel.PRODUCTION, string.Format("unable to find subFolder {0} to move items to... Creating", moveToSubFolder));
                    destinationFolderId = CreateFolder(moveToSubFolder, ServiceEmailAddress, out sErrorMessage).Id.UniqueId;
                }
            }

            do
            {
                try
                {
                    Logger.Log(LogLevel.DEBUG, string.Format("trying to find emails based on search filter. Folder: {0}", folderToSearch));
                    findResults = Service.FindItems(folderToSearch, sf, view);
                }
                catch (Exception ex)
                {
                    sErrorMessage = ex.Message;
                    Logger.Log(LogLevel.PRODUCTION, string.Format("failed to retrieve mail items from the search location. {0}", sErrorMessage));
                    Logger.StopTimer();
                    Logger.LogNoDate("\r---");
                    return;
                }
                if (findResults.Items.Count == 0) break;

                if (findResults.MoreAvailable)
                    view.Offset += 50;

                Service.LoadPropertiesForItems(findResults.Items, propSet);

                foreach (var item in findResults)
                {
                    Logger.StartTimer();
                    Logger.Log(LogLevel.DEBUG, string.Format("retrieving email {0}", EmailCollection.Rows.Count + 1));

                    // bind the item found to an email message
                    EmailMessage msg = EmailMessage.Bind(Service, item.Id);
                    EmailMessage movedEmail = null;
                    ItemId messageId = msg.Id;
                    toList = string.Empty;
                    ccList = string.Empty;
                    attachmentNames = string.Empty;

                    item.Load(propSet);

                    // Will either build a string with the SMTP addresses of to/cc or their names
                    if (IncludeEmailAddresses)
                    {
                        builder.Clear();
                        msg.ToRecipients.ToList().ForEach(x => builder.Append(x.Address + ";"));
                        if (builder.Length > 0) builder.Remove(builder.Length - 1, 1);
                        toList = builder.ToString();

                        builder.Clear();
                        msg.CcRecipients.ToList().ForEach(x => builder.Append(x.Address + ";"));
                        if (builder.Length > 0) builder.Remove(builder.Length - 1, 1);
                        ccList = builder.ToString();
                    }
                    else
                    {
                        toList = msg.DisplayTo ?? string.Empty;
                        ccList = msg.DisplayCc ?? string.Empty;
                    }

                    // builds the attachment names string
                    builder.Clear();
                    var currentEmailCount = EmailCollection.Rows.Count;
                    msg.Attachments.ToList().ForEach(x => builder.Append((AttachmentDir == "")
                                                                                        ? ""
                                                                                        : currentEmailCount + "_")
                                                                .Append(CleanSpecialCharacters(x.Name) + ";"));
                    if (builder.Length > 0) builder.Remove(builder.Length - 1, 1);
                    attachmentNames = builder.ToString();

                    // if an attachment directory was specified, save files to the location
                    if (msg.Attachments.Count > 0 && AttachmentDir != "")
                    {
                        if (!AttachmentDir.EndsWith("\\"))
                            AttachmentDir += "\\";

                        try
                        {
                            GetAttachments(msg, currentEmailCount, AttachmentDir);
                        }
                        catch (FailedToSaveAttachmentException ex)
                        {
                            string newId = "";
                            bool success = false;
                            string errorMessage = "";
                            MoveMail(messageId.UniqueId, "Unprocessed Emails", ServiceEmailAddress, out newId, out success, out errorMessage);
                            UnprocessedEmailCollection.Rows.Add(msg.From.Name, msg.From.Address, item.Subject, item.Body,
                                            item.DateTimeReceived, item.DateTimeSent, toList, ccList,
                                            msg.Attachments.Count, attachmentNames, newId);
                            continue;
                        }
                    }

                    // mark the message as read and update the folder
                    msg.IsRead = true;
                    Service.UpdateItems(new List<EmailMessage> { msg }, folderToSearch,
                                            ConflictResolutionMode.AutoResolve, null, null);

                    if (destinationFolderId != null)
                    {
                        Logger.Log(LogLevel.DEBUG, "attempting to move email to destination folder");
                        Item movedItem = msg.Move(destinationFolderId);
                        movedEmail = EmailMessage.Bind(Service, movedItem.Id);
                        messageId = movedEmail.Id;
                        Logger.Log(LogLevel.DEBUG, "done moving email");
                    }

                    // Create a new row in the Data Table
                    Logger.Log(LogLevel.DEBUG, "adding new row to the email data table");
                    EmailCollection.Rows.Add(msg.From.Name, msg.From.Address, item.Subject, item.Body,
                                            item.DateTimeReceived, item.DateTimeSent, toList, ccList,
                                            msg.Attachments.Count, attachmentNames, Delete ? "" : messageId.UniqueId);

                    TotalAttachmentCount += msg.Attachments.Count;
                    if (Delete)
                    {
                        Logger.Log(LogLevel.DEBUG, "deleting email");
                        msg.Delete(DeleteMode.MoveToDeletedItems);
                    }

                    Logger.Log(LogLevel.DEBUG, "done retrieving email");
                    Logger.StopTimer();

                }
            } while (findResults.MoreAvailable);

            NumberOfEmails = EmailCollection.Rows.Count;
            Logger.Log(LogLevel.PRODUCTION, string.Format("Finished reading emails. Returning {0} emails in collection\n", NumberOfEmails));
            Logger.StopTimer();
            Logger.LogNoDate("\r---");
        }

        public void MoveMail(string ID, string SubFolder, string ServiceEmailAddress, out string NewId, out bool Success, out string ErrorMessage)
        {
            Logger.Log(LogLevel.PRODUCTION, string.Format("attempting to move email to subfolder {0}", SubFolder));
            Logger.StartTimer();
            NewId = string.Empty;
            ErrorMessage = string.Empty;
            Success = true;
            EmailMessage beforeMessage = null;

            try
            {
                Logger.Log(LogLevel.DEBUG, "attempting to bind to the initial email");
                beforeMessage = EmailMessage.Bind(Service, new ItemId(ID));
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
                Success = false;
                Logger.Log(LogLevel.PRODUCTION, string.Format("failed to bind to the initial email.\t{0}", ex.Message));
                Logger.StopTimer();
                Logger.LogNoDate("\r---");
                return;
            }

            if (beforeMessage == null)
            {
                ErrorMessage = "Unable to find email";
                Success = false;
                return;
            }

            Logger.Log(LogLevel.DEBUG, string.Format("attempting to retrieve the ID of subfolder {0}", SubFolder));
            Folder folder = GetChildSubfolder(SubFolder, ServiceEmailAddress, out ErrorMessage);
            if (folder == null)
            {
                Logger.Log(LogLevel.PRODUCTION, string.Format("unable to find subfolder ID. Creating folder structure {0}...", SubFolder));
                folder = CreateFolder(SubFolder, ServiceEmailAddress, out ErrorMessage);
            }

            Item movedItem = beforeMessage.Move(folder.Id.UniqueId);

            if (movedItem == null)
            {
                ErrorMessage = "Unable to move email";
                Success = false;
                Logger.Log(LogLevel.PRODUCTION, string.Format("unable to move email to subfolder {0}", SubFolder));
                Logger.StopTimer();
                Logger.LogNoDate("\r---");
                return;
            }

            EmailMessage movedMessage = EmailMessage.Bind(Service, movedItem.Id);
            if (movedMessage == null)
            {
                ErrorMessage = "Unable to bind to the newly moved item";
                Success = false;
                Logger.Log(LogLevel.PRODUCTION, string.Format("unable to bind moved item to an email message."));
                Logger.StopTimer();
                Logger.LogNoDate("\r---");
                return;
            }

            NewId = movedMessage.Id.UniqueId;
            Logger.Log(LogLevel.DEBUG, "done moving email.");
            Logger.StopTimer();
            Logger.LogNoDate("\r---");
        }


        
        //private void GetAttachments(EmailMessage msg, int currentEmailCount, string attachmentDir)

        public void MoveEmailToFolder(string id, string dir)
        {


            PropertySet props = new PropertySet(EmailMessageSchema.MimeContent);
            // bind the item found to an email message
            EmailMessage msg = EmailMessage.Bind(Service, id, props );
            ItemId itemId = msg.Id;
            string fileName = msg.Subject;

            try
            {
                Logger.Log(LogLevel.DEBUG, "attempting to bind initial email");

                // save eml file including FileAttachment together
                // bind to the email using the ID input param
     
                        fileName = CleanSpecialCharacters(msg.Subject)+".eml";

                     
                       string path =  Path.Combine(dir, fileName, ".eml");

                using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write))
                        {
                            fs.Write(msg.MimeContent.Content, 0, msg.MimeContent.Content.Length);
                        }  
            }

            catch (Exception ex)
            {
                Logger.Log(LogLevel.PRODUCTION, string.Format("failed to store the mail into the folder.\t{0}", ex.Message));
                Logger.StopTimer();
                Logger.LogNoDate("\r---");
                return;
            }
        }




        public string FindMailWithLanID(string pLanID)
        {
            string mail = "";
            DirectoryEntry entry = new DirectoryEntry("LDAP://" + "globsai.saifg.rbc.com" + "/ou=people,dc=fg,dc=rbc,dc=com", "ou=RPX0,ou=applications,dc=fg,dc=rbc,dc=com", "9+^pB:tn", AuthenticationTypes.None);
            DirectorySearcher searcher = new DirectorySearcher(entry);

            searcher.Filter = "(&(ntUserDomainId=" + pLanID + "))";  //filter for "searching condition = LanId"
            searcher.ReferralChasing = ReferralChasingOption.None;      // 
            searcher.ServerTimeLimit = System.TimeSpan.FromSeconds(20);// 0.02 seconds
            searcher.SizeLimit = 5;

            searcher.PropertiesToLoad.Add("mail");  //being specific to mail

            SearchResult result = searcher.FindOne(); //to find just one member cause all LanIds are unique so the reuslt is always one so we dont find all

            if (result.Properties.Contains("mail"))  // this is getting value from the result   // result is result value of the search result
            {
                if (result.Properties["mail"][0].GetType().IsArray)  // so this specidfies the type as array and gets the first value in the array
                {
                    mail = System.Text.Encoding.UTF8.GetString((byte[])result.Properties["mail"][0]);
                }
                else
                {
                    mail = result.Properties["mail"][0].ToString();
                }
            }

            searcher.Dispose(); //closing
            entry.Close();

            return mail;
        }






        public void SendMailWithGenericMailbox(string sEmailAddress, string sToRecipients, string sCcRecipients, string sBccRecipients, string sSubject, string sBody, string sAttachments,
            out string sErrorMessage, string sPriority = "normal", bool HTML = false)
        {
            Logger.Log(LogLevel.PRODUCTION, string.Format("attempting to send an email from {0}", sEmailAddress));
            Logger.StartTimer();
            sErrorMessage = "";

            Logger.Log(LogLevel.DEBUG, "creating a new email message");
            EmailMessage emCurrent = new EmailMessage(Service);

            Regex emRegex = new Regex(@"^[\w]+([.]?[\w]+)?@[\w]+(\.(com)){1}$");
            Regex lanIdRegex = new Regex(@"^[\d]{9}$");

            emCurrent.From = new EmailAddress(sEmailAddress);
            emCurrent.ReplyTo.Add(sEmailAddress);

            String[] aRecipients = sToRecipients.Split(';');

            Logger.Log(LogLevel.DEBUG, "building the to recipients");
            foreach (String sRecipient in aRecipients)
            {
                if (!sRecipient.Equals(""))
                {
                    if (lanIdRegex.Match(sRecipient).Success)
                    {
                        try
                        {
                            emCurrent.ToRecipients.Add(FindMailWithLanID(sRecipient).Trim());
                        }
                        catch (Exception ex)
                        {
                            Logger.Log(LogLevel.PRODUCTION, string.Format("Unable to find email address for TO Recipient {0}", sRecipient));
                            Logger.Log(LogLevel.PRODUCTION, ex.Message);
                        }
                    }
                    else
                    {
                        emCurrent.ToRecipients.Add(sRecipient.ToString().Trim());
                    }
                }
            }

            aRecipients = sCcRecipients.Split(';');
            Logger.Log(LogLevel.DEBUG, "building the cc recipients");
            foreach (String sRecipient in aRecipients)
            {
                if (!sRecipient.Equals(""))
                {
                    if (lanIdRegex.Match(sRecipient).Success)
                    {
                        try
                        {
                            emCurrent.CcRecipients.Add(FindMailWithLanID(sRecipient).Trim());
                        }
                        catch (Exception ex)
                        {
                            Logger.Log(LogLevel.PRODUCTION, string.Format("Unable to find email address for CC Recipient {0}", sRecipient));
                            Logger.Log(LogLevel.PRODUCTION, ex.Message);
                        }
                    }
                    else
                    {
                        emCurrent.CcRecipients.Add(sRecipient.ToString().Trim());
                    }
                }
            }

            aRecipients = sBccRecipients.Split(';');
            Logger.Log(LogLevel.DEBUG, "building the bcc recipients");
            foreach (String sRecipient in aRecipients)
            {
                if (!sRecipient.Equals(""))
                {
                    if (lanIdRegex.Match(sRecipient).Success)
                    {
                        try
                        {
                            emCurrent.BccRecipients.Add(FindMailWithLanID(sRecipient).Trim());
                        }
                        catch (Exception ex)
                        {
                            Logger.Log(LogLevel.PRODUCTION, string.Format("Unable to find email address for BCC Recipient {0}", sRecipient));
                            Logger.Log(LogLevel.PRODUCTION, ex.Message);
                        }
                    }
                    else
                    {
                        emCurrent.BccRecipients.Add(sRecipient.ToString().Trim());
                    }
                }
            }

            if (emCurrent.ToRecipients.Count + emCurrent.CcRecipients.Count + emCurrent.BccRecipients.Count == 0)
            {
                sErrorMessage = string.Format("Unable to send an email when no recipients are added. To: <{0}> CC: <{1}> BCC: <{2}>", sToRecipients, sCcRecipients, sBccRecipients);
                Logger.Log(LogLevel.PRODUCTION, sErrorMessage);
                return;
            }

            emCurrent.Subject = sSubject;
            if (HTML)
            {
                Logger.Log(LogLevel.DEBUG, "setting the body type to HTML");
                emCurrent.Body = new MessageBody(BodyType.HTML, sBody);
            }

            else
            {
                Logger.Log(LogLevel.DEBUG, "setting the body type to Text");
                emCurrent.Body = new MessageBody(BodyType.Text, sBody);
            }


            String[] aAttachments = sAttachments.Split(';');
            foreach (String sAttachment in aAttachments)
            {
                if (sAttachment != "")
                {
                    Logger.Log(LogLevel.DEBUG, string.Format("adding file attachment {0} to the email", sAttachment));
                    emCurrent.Attachments.AddFileAttachment(sAttachment);
                }
            }

            if (sPriority.Equals("high", StringComparison.CurrentCultureIgnoreCase))
            {
                Logger.Log(LogLevel.DEBUG, "setting the email priority to high");
                emCurrent.Importance = Importance.High;
            }
            else if (sPriority.Equals("low", StringComparison.CurrentCultureIgnoreCase))
            {
                Logger.Log(LogLevel.DEBUG, "setting the email priority to low");
                emCurrent.Importance = Importance.Low;
            }
            else
            {
                Logger.Log(LogLevel.DEBUG, "setting the email priority to normal");
                emCurrent.Importance = Importance.Normal;
            }

            try
            {
                Logger.Log(LogLevel.PRODUCTION, string.Format("attempting to send the email and save a copy to the sent items folder of {0}", sEmailAddress));
                var destinationFolder = new FolderId(WellKnownFolderName.SentItems, new Mailbox(sEmailAddress));
                emCurrent.SendAndSaveCopy(destinationFolder);
            }
            catch (Exception ex)
            {
                sErrorMessage = ex.Message;
                Logger.Log(LogLevel.PRODUCTION, string.Format("unable to send email\t{0}", ex.Message));
                Logger.StopTimer();
                Logger.LogNoDate("\r---");
                return;
            }

            Logger.Log(LogLevel.DEBUG, "done saving email. Sent...");
            Logger.StopTimer();
            Logger.LogNoDate("\r---");
        }

        public void SendMail(string sEmailAddress, string sToRecipients, string sCcRecipients, string sBccRecipients, string sSubject, string sBody, string sAttachments,
            string sPriority = "normal", bool HTML = false)
        {
            var sErrorMessage = "";

            EmailMessage emCurrent = new EmailMessage(Service);

            emCurrent.From = new EmailAddress(sEmailAddress);
            emCurrent.ReplyTo.Add(sEmailAddress);

            String[] aRecipients = sToRecipients.Split(';');

            foreach (String sRecipient in aRecipients)
            {
                if (!sRecipient.Equals(""))
                {
                    emCurrent.ToRecipients.Add(sRecipient.ToString().Trim());
                }
            }

            aRecipients = sCcRecipients.Split(';');

            foreach (String sRecipient in aRecipients)
            {
                if (!sRecipient.Equals(""))
                {
                    emCurrent.CcRecipients.Add(sRecipient.ToString().Trim());
                }
            }

            aRecipients = sBccRecipients.Split(';');

            foreach (String sRecipient in aRecipients)
            {
                if (!sRecipient.Equals(""))
                {
                    emCurrent.BccRecipients.Add(sRecipient.ToString().Trim());
                }
            }

            emCurrent.Subject = sSubject;
            if (HTML)
                emCurrent.Body = new MessageBody(BodyType.HTML, sBody);
            else
                emCurrent.Body = new MessageBody(BodyType.Text, sBody);

            String[] aAttachments = sAttachments.Split(';');
            foreach (String sAttachment in aAttachments)
            {
                if (sAttachment != "")
                    emCurrent.Attachments.AddFileAttachment(sAttachment);
            }

            if (sPriority.Equals("high", StringComparison.CurrentCultureIgnoreCase))
                emCurrent.Importance = Importance.High;
            else if (sPriority.Equals("low", StringComparison.CurrentCultureIgnoreCase))
                emCurrent.Importance = Importance.Low;
            else
                emCurrent.Importance = Importance.Normal;

            try
            {
                var destinationFolder = new FolderId(WellKnownFolderName.SentItems, new Mailbox(sEmailAddress));
                emCurrent.SendAndSaveCopy(destinationFolder);
            }
            catch (Exception ex)
            {
                sErrorMessage = ex.Message;
                return;
            }
        }

        public void ReplyToMail(string id, string emailAddress, bool replyToAll, bool includeOriginalEmail, string message, string attachment, out bool Success, out string ErrorMessage)
        {
            Success = true;
            ErrorMessage = "";
            EmailMessage initial = null;

            try
            {
                initial = EmailMessage.Bind(Service, new ItemId(id));
                initial.Load(new PropertySet(BasePropertySet.FirstClassProperties) { RequestedBodyType = BodyType.Text });
            }
            catch (Exception ex)
            {
                Success = false;
                ErrorMessage = ex.Message;
                return;
            }

            if (initial == null)
            {
                ErrorMessage = "Could not locate email to reply to";
                return;
            }

            EmailMessage reply = new EmailMessage(Service);

            reply.Subject = (initial.Subject.StartsWith("RE:")) ? initial.Subject : "RE: " + initial.Subject;

            reply.ToRecipients.Add(initial.From);

            if (replyToAll)
            {
                reply.ToRecipients.AddRange(initial.ToRecipients.Where(x => !x.Address.Equals(emailAddress)));
                reply.CcRecipients.AddRange(initial.CcRecipients.Where(x => !x.Address.Equals(emailAddress)));
            }

            string[] aAttachments = attachment.Split(';');
            foreach (string sAttachment in aAttachments)
            {
                if (sAttachment != "")
                {
                    reply.Attachments.AddFileAttachment(sAttachment);
                }

            }

            var builder = new StringBuilder(message);
            if (includeOriginalEmail)
            {
                builder.AppendLine().AppendLine()
                    .AppendLine("-----Original Message-----")
                    .Append("From: ").AppendLine(initial.From.Name)
                    .Append("Sent: ").Append(initial.DateTimeSent).AppendLine()
                    .Append("To: ").AppendLine(initial.DisplayTo);
                if (initial.CcRecipients.Count > 0)
                    builder.Append("CC: ").AppendLine(initial.DisplayCc);
                builder.Append("Subject: ").AppendLine(initial.Subject)
                    .AppendLine()
                    .Append(initial.Body);
            }
            reply.Body = new MessageBody(BodyType.Text, builder.ToString());

            var destinationFolder = new FolderId(WellKnownFolderName.SentItems, new Mailbox(emailAddress));
            reply.SendAndSaveCopy(destinationFolder);
        }
    }
}
