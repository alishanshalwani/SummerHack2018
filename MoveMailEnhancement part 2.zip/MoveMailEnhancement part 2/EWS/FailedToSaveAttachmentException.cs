﻿using System;
using System.Runtime.Serialization;

namespace ExchangeWebServices
{
    [Serializable]
    public class FailedToSaveAttachmentException : Exception
    {
        public FailedToSaveAttachmentException()
        {
        }

        public FailedToSaveAttachmentException(string message) : base(message)
        {
        }

        public FailedToSaveAttachmentException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected FailedToSaveAttachmentException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
