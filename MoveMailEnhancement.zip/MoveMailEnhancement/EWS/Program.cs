﻿using BluePrismLoggingFramework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Microsoft.Exchange.WebServices.Data;
using System.Threading.Tasks;

namespace ExchangeWebServices
{
    class Program
    {
        static void Main(string[] args)
        {
            Logger.LoadConfig();
            Logger.FileName = String.Format("ExchangeWebServices_Log_{0}.txt", DateTime.Now.ToString("MM-dd-yy"));

            EWS mail = new EWS();



            //DataTable col = null;
            //DataTable unprocessed = null;
           //string password = Console.ReadLine();v
            mail.Authenticate("324129543","Password12345", "SAIMAPLE", "tyler.babin@istrbc.com", "https://sainamail.saifg.rbc.com/EWS/Exchange.asmx", out string def);
            //mail.SendMailWithGenericMailbox("tyler.babin@istrbc.com", "322122292;tyler.babin@istrbc.com", "", "", "ToRecipient", "testing email1", "", out string err);
          //  mail.SendMailWithGenericMailbox("alishan.shalwani@istrbc.com", "tyler.babin@istrbc.com", "322122292;324129543", "", "CCRecipient", "testing email2", "", out err);
          //  mail.SendMailWithGenericMailbox("alishan.shalwani@sterbc.com", "581686284;322122292;tyler.babin@sterbc.com", "322122292;tyler.babin@sterbc.com", "322122292", "BccRecipient", "testing email3", "", out err);

            //Console.ReadLine();

            mail.GetMailBp(true, true, "tyler.babin@istrbc.com", out DataTable emails, out DataTable unprocessed, out decimal num, out decimal att, out string err1);
            //string id = emails.Rows[0].ToString();
           string id = emails.Rows[1]["ID"].ToString();

            mail.MoveEmailToFolder(id, "C:\\Users\\322122292\\Desktop\\TestAttachmentEML");

            //mail.Service.
            //EmailMessage msg = EmailMessage.Bind(mail.Service, id);






        }
    }
}
