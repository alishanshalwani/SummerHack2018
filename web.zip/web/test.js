// @ts-check

class MarkerManager {
  /**
   * @param {google.maps.Map} map
   */
  constructor(map) {
    this.map = map;
    this.directionsService = new google.maps.DirectionsService();
    this.directionsDisplay = new google.maps.DirectionsRenderer({
      suppressMarkers: true
    });
    this.directionsDisplay.setMap(this.map);

    /** @type {google.maps.LatLng|google.maps.LatLngLiteral} */
    this.origin = null;
    /** @type {google.maps.LatLng|google.maps.LatLngLiteral} */
    this.destination = null;
    this.travelMode = google.maps.TravelMode.WALKING;

    this.originMarker = new google.maps.Marker({
      position: { lat: 0, lng: 0 },
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        fillColor: "#4285f4",
        fillOpacity: 1,
        strokeColor: "#fff",
        strokeWeight: 2,
        scale: 10
      }
    });
    this.destinationMarker = new google.maps.Marker({
      position: { lat: 0, lng: 0 }
    });
  }

  /**
   * Displays directions on the map, depending on the current
   * `origin`, `destination`, and `travelMode`.
   */
  async displayRoute() {
    if (!this.origin || !this.destination) return;

    /** @type {google.maps.DirectionsResult} */
    const response = await new Promise((resolve, reject) =>
      this.directionsService.route({
        origin: this.origin,
        destination: this.destination,
        travelMode: this.travelMode,
      }, (response, status) => {
        if (status === google.maps.DirectionsStatus.OK) {
          resolve(response);
        } else {
          reject(status);
        }
      })
    );

    this.directionsDisplay.setDirections(response);

    const bounds = new google.maps.LatLngBounds();
    bounds.extend(this.origin).extend(this.destination);
    this.map.fitBounds(bounds);
  }

  /**
   * Returns the user's location as a LatLng. If the position cannot
   * be found, returns null instead. Additionally sets the user position
   * as the `origin` in the manager.
   * @returns {Promise<google.maps.LatLngLiteral>}
   */
  async getUserLocation() {
    if ("geolocation" in navigator) {
      /** @type {Position} */
      const pos = await new Promise((resolve, reject) =>
        navigator.geolocation.getCurrentPosition(resolve, reject)
      );

      console.log(`Lat: ${pos.coords.latitude} Lng: ${pos.coords.longitude}`);

      /** @type {google.maps.LatLngLiteral} */
      const position = {
        lat: pos.coords.latitude,
        lng: pos.coords.longitude
      };
      this.origin = position;
      this.originMarker.setPosition(this.origin);
      this.originMarker.setMap(this.map);

      this.displayRoute();

      return position;
    } else {
      return null;
    }
  }

  /**
   * Adds a change event listner to the container, which will set
   * `travelMode` to the value of the changed radio button.
   * @param {HTMLElement} radioButtonContainer
   */
  setupTravelModeChangeListener(radioButtonContainer) {
    radioButtonContainer.addEventListener("change", event => {
      const radio = /** @type {HTMLInputElement} */ (event.target);
      this.travelMode = /** @type {any} */ (radio.value);
      this.displayRoute();
    });
    return this;
  }

  /**
   * Converts the given input element into a Google Maps search box,
   * then adds a places_changed event listener to the search box which
   * sets the destination.
   * @param {HTMLInputElement} searchInput
   */
  setupSearchBoxListener(searchInput) {
    const searchBox = new google.maps.places.SearchBox(searchInput);

    // Proposes locations within the bounds
    this.map.addListener("bounds_changed", () => {
      searchBox.setBounds(this.map.getBounds());
    });

    searchBox.addListener("places_changed", async () => {
      // [place] gets first element of iterator
      const [place] = searchBox.getPlaces();
      if (place != null) {
        this.destination = place.geometry.location;
        this.destinationMarker.setPosition(this.destination);
        this.destinationMarker.setMap(this.map);

        this.displayRoute();
      }
    });
    return this;
  }
}

/** @type {Map<google.maps.Marker, google.maps.InfoWindow>} */
const markersToInfoWindow = new Map();

/**
 * @param {google.maps.Map} map
 * @param {Array<{coords: google.maps.LatLngLiteral, content: string}>} markerProps
 */
function showMarkers(map, markerProps) {
  for (const props of markerProps) {
    const marker = new google.maps.Marker({
      position: props.coords,
      map: map
    });

    if (props.content) {
      const infoWindow = new google.maps.InfoWindow({
        content: props.content
      });
      markersToInfoWindow.set(marker, infoWindow);

      marker.addListener("click", () => {
        hideAllInfoWindows(map);
        infoWindow.open(map, marker);
      });
    }

    function hideAllInfoWindows(map) {
      for (const infoWindow of markersToInfoWindow.values()) {
        infoWindow.close();
      }
    }
  }
}

async function initMap() {
  // New map
  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 15,
    center: { lat: 43.6457, lng: -79.385 }
  });

  // Create the search box and link it to the UI element.
  const search = /** @type {HTMLInputElement} */ (document.getElementById(
    "pac-input"
  ));
  const modeSelector = document.getElementById("mode-selector");

  map.controls[google.maps.ControlPosition.TOP_LEFT].push(search);
  map.controls[google.maps.ControlPosition.TOP_LEFT].push(modeSelector);

  const directionsState = new MarkerManager(map)
    .setupTravelModeChangeListener(modeSelector)
    .setupSearchBoxListener(search);
  directionsState.getUserLocation();
}

/**
 *
 * @param {HTMLElement} element
 */
function togglePopout(element) {
  element.classList.toggle("popout");
}
